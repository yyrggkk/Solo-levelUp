// client/src/components/BattleScreen.tsx
import React from 'react';

interface BattleScreenProps {
  player: Player;
  enemy: Enemy;
  onBattleAction: (action: 'attack' | 'useItem', item?: string) => void;
  onRunAway: () => void;
}

const BattleScreen: React.FC<BattleScreenProps> = ({ player, enemy, onBattleAction, onRunAway }) => {
  const [battleLog, setBattleLog] = useState<string[]>([]);

  const handleAttack = () => {
    const playerRoll = Math.floor(Math.random() * 6) + 1;
    const damage = Math.max(1, player.attack + playerRoll - enemy.defense);
    
    setBattleLog([...battleLog, 
      `هاجمت العدو وحققت ${damage} ضرر!`,
      `نقاط صحة العدو المتبقية: ${enemy.hp - damage}`
    ]);
    
    onBattleAction('attack');
  };

  return (
    <div className="battle-screen">
      <h2>⚔️ معركة ضد {enemy.name} ⚔️</h2>
      
      <div className="battle-status">
        <div className="player-status">
          <h3>{player.name}</h3>
          <p>الصحة: {player.hp}/{player.maxHp}</p>
        </div>
        
        <div className="vs">VS</div>
        
        <div className="enemy-status">
          <h3>{enemy.name}</h3>
          <p>الصحة: {enemy.hp}/{enemy.maxHp}</p>
        </div>
      </div>
      
      <div className="battle-log">
        {battleLog.map((log, index) => (
          <p key={index}>{log}</p>
        ))}
      </div>
      
      <div className="battle-actions">
        <button onClick={handleAttack}>الهجوم</button>
        <button onClick={() => onBattleAction('useItem')}>استخدام عنصر</button>
        <button onClick={onRunAway}>الهروب</button>
      </div>
    </div>
  );
};

export default BattleScreen;