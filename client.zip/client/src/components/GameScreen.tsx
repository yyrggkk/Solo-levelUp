// client/src/components/GameScreen.tsx
import React, { useState, useEffect } from 'react';
import PlayerStatus from './PlayerStatus';
import LocationView from './LocationView';
import BattleScreen from './BattleScreen';
import Inventory from './Inventory';
import Shop from './Shop';

interface GameScreenProps {
  player: Player;
  onAction: (action: GameAction) => void;
}

const GameScreen: React.FC<GameScreenProps> = ({ player, onAction }) => {
  const [currentView, setCurrentView] = useState<'main' | 'battle' | 'inventory' | 'shop'>('main');
  const [enemy, setEnemy] = useState<Enemy | null>(null);

  const handleLocationSelect = (location: string) => {
    // معالجة اختيار الموقع
    const action: GameAction = { type: 'move', location };
    onAction(action);
    
    // 30% فرصة للمعركة في المواقع الخارجية
    if (location !== 'المنزل' && location !== 'المتجر' && Math.random() < 0.3) {
      const enemy = generateEnemy(location);
      setEnemy(enemy);
      setCurrentView('battle');
    }
  };

  return (
    <div className="game-container">
      <PlayerStatus player={player} />
      
      {currentView === 'main' && (
        <LocationView 
          currentLocation={player.location}
          onLocationSelect={handleLocationSelect}
          onOpenInventory={() => setCurrentView('inventory')}
          onOpenShop={() => setCurrentView('shop')}
        />
      )}
      
      {currentView === 'battle' && enemy && (
        <BattleScreen 
          player={player}
          enemy={enemy}
          onBattleAction={(action) => onAction({ type: 'battle', ...action })}
          onRunAway={() => setCurrentView('main')}
        />
      )}
      
      {currentView === 'inventory' && (
        <Inventory 
          items={player.inventory}
          onUseItem={(item) => onAction({ type: 'useItem', item })}
          onClose={() => setCurrentView('main')}
        />
      )}
      
      {currentView === 'shop' && (
        <Shop 
          player={player}
          onPurchase={(item) => onAction({ type: 'purchase', item })}
          onClose={() => setCurrentView('main')}
        />
      )}
    </div>
  );
};

export default GameScreen;