// shared/models.ts
export interface Player {
  name: string;
  level: number;
  exp: number;
  hp: number;
  maxHp: number;
  attack: number;
  defense: number;
  luck: number;
  agility: number;
  upgradePoints: number;
  gold: number;
  inventory: string[];
  location: string;
  alive: boolean;
  extraLife: boolean;
  dungeonDepth: number;
  currentDungeon: Dungeon | null;
}

export interface Enemy {
  name: string;
  hp: number;
  maxHp: number;
  attack: number;
  defense: number;
}

export interface Dungeon {
  difficulty: string;
  enemies: string[];
  boss: string;
  reward: number;
}

export type GameAction = 
  | { type: 'move', location: string }
  | { type: 'battle', action: 'attack' | 'useItem', item?: string }
  | { type: 'useItem', item: string }
  | { type: 'purchase', item: string }
  | { type: 'levelUp', stat: keyof Player }
  | { type: 'save' }
  | { type: 'load' };