// server/index.js
const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const { Player } = require('./models');

const app = express();
app.use(cors());
app.use(express.json());

// الاتصال بقاعدة البيانات
mongoose.connect('mongodb://localhost:27017/island_adventure', {
  useNewUrlParser: true,
  useUnifiedTopology: true
});

// مسارات API
app.post('/api/game/start', async (req, res) => {
  const { name, load } = req.body;
  
  if (load) {
    const savedGame = await Player.findOne({ name });
    if (savedGame) {
      return res.json(savedGame);
    }
    return res.status(404).json({ error: 'No saved game found' });
  }
  
  const newPlayer = new Player({
    name,
    level: 1,
    exp: 0,
    hp: 100,
    maxHp: 100,
    attack: 10,
    defense: 5,
    luck: 1,
    agility: 1,
    upgradePoints: 0,
    gold: 0,
    inventory: [],
    location: "المنزل",
    alive: true,
    extraLife: true,
    dungeonDepth: 0,
    currentDungeon: null
  });
  
  await newPlayer.save();
  res.json(newPlayer);
});

app.post('/api/game/action', async (req, res) => {
  const { name, action } = req.body;
  const player = await Player.findOne({ name });
  
  if (!player) {
    return res.status(404).json({ error: 'Player not found' });
  }
  
  // معالجة الإجراءات المختلفة
  switch (action.type) {
    case 'move':
      player.location = action.location;
      break;
    case 'battle':
      // معالجة المعركة
      break;
    case 'useItem':
      // استخدام العنصر
      break;
    case 'purchase':
      // شراء عنصر من المتجر
      break;
    case 'levelUp':
      // تحسين الإحصائيات
      break;
    case 'save':
      // حفظ اللعبة (يتم تلقائياً في قاعدة البيانات)
      break;
  }
  
  await player.save();
  res.json(player);
});

const PORT = 5000;
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});